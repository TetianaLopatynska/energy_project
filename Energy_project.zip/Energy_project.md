```python
import pandas as pd

# Loading data from files
renewable_energy_data = pd.read_csv(r'C:\Users\Tetiana_Lopatynska\OneDrive - EPAM\Desktop\Data analyst\Course Data Analyst Changers\Final Project\country_capacity.csv')
gdp_data = pd.read_csv(r'C:\Users\Tetiana_Lopatynska\OneDrive - EPAM\Desktop\Data analyst\Course Data Analyst Changers\Final Project\Country, year, GDP 2015-2023.csv')

```


```python
renewable_energy_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Group_Technology</th>
      <th>Technology</th>
      <th>RE_or_Non_RE</th>
      <th>Year</th>
      <th>Electricity_Installed_Capacity__MW_</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Albania</td>
      <td>Bioenergy</td>
      <td>Renewable municipal waste</td>
      <td>Total Renewable</td>
      <td>2017</td>
      <td>1.425</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>Bioenergy</td>
      <td>Renewable municipal waste</td>
      <td>Total Renewable</td>
      <td>2018</td>
      <td>1.425</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Albania</td>
      <td>Bioenergy</td>
      <td>Renewable municipal waste</td>
      <td>Total Renewable</td>
      <td>2019</td>
      <td>1.425</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>Bioenergy</td>
      <td>Renewable municipal waste</td>
      <td>Total Renewable</td>
      <td>2020</td>
      <td>1.425</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Albania</td>
      <td>Bioenergy</td>
      <td>Renewable municipal waste</td>
      <td>Total Renewable</td>
      <td>2021</td>
      <td>1.425</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>4268</th>
      <td>United Kingdom</td>
      <td>Hydropower (excl. Pumped Storage)</td>
      <td>Renewable hydropower</td>
      <td>Total Renewable</td>
      <td>2019</td>
      <td>1879.860</td>
    </tr>
    <tr>
      <th>4269</th>
      <td>United Kingdom</td>
      <td>Hydropower (excl. Pumped Storage)</td>
      <td>Renewable hydropower</td>
      <td>Total Renewable</td>
      <td>2020</td>
      <td>1885.264</td>
    </tr>
    <tr>
      <th>4270</th>
      <td>United Kingdom</td>
      <td>Hydropower (excl. Pumped Storage)</td>
      <td>Renewable hydropower</td>
      <td>Total Renewable</td>
      <td>2021</td>
      <td>1890.434</td>
    </tr>
    <tr>
      <th>4271</th>
      <td>United Kingdom</td>
      <td>Hydropower (excl. Pumped Storage)</td>
      <td>Renewable hydropower</td>
      <td>Total Renewable</td>
      <td>2022</td>
      <td>1890.434</td>
    </tr>
    <tr>
      <th>4272</th>
      <td>United Kingdom</td>
      <td>Hydropower (excl. Pumped Storage)</td>
      <td>Renewable hydropower</td>
      <td>Total Renewable</td>
      <td>2023</td>
      <td>1890.434</td>
    </tr>
  </tbody>
</table>
<p>4273 rows × 6 columns</p>
</div>




```python
gdp_data
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Country</th>
      <th>Year</th>
      <th>GDP</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Albania</td>
      <td>2015</td>
      <td>11.387</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Albania</td>
      <td>2016</td>
      <td>11.861</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Albania</td>
      <td>2017</td>
      <td>13.020</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Albania</td>
      <td>2018</td>
      <td>15.156</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Albania</td>
      <td>2019</td>
      <td>15.402</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>373</th>
      <td>United Kingdom</td>
      <td>2019</td>
      <td>2851.407</td>
    </tr>
    <tr>
      <th>374</th>
      <td>United Kingdom</td>
      <td>2020</td>
      <td>2697.807</td>
    </tr>
    <tr>
      <th>375</th>
      <td>United Kingdom</td>
      <td>2021</td>
      <td>3141.506</td>
    </tr>
    <tr>
      <th>376</th>
      <td>United Kingdom</td>
      <td>2022</td>
      <td>3089.073</td>
    </tr>
    <tr>
      <th>377</th>
      <td>United Kingdom</td>
      <td>2023</td>
      <td>3332.059</td>
    </tr>
  </tbody>
</table>
<p>378 rows × 3 columns</p>
</div>




```python
# Create pivot table
pivot_table = renewable_energy_data.pivot_table(index='Country', columns='RE_or_Non_RE', values='Electricity_Installed_Capacity__MW_', aggfunc='sum')

# Rename columns for convenience
pivot_table.rename(columns={'Total Renewable': 'Total_Renewable', 'Total Non-Renewable': 'Total_Non_Renewable'}, inplace=True)

# Display result
print(pivot_table)
```

    RE_or_Non_RE            Total_Non_Renewable  Total_Renewable
    Country                                                     
    Albania                             880.850        20163.025
    Andorra                              13.900          479.178
    Austria                           47769.190       192021.329
    Belarus                           91515.600         3665.460
    Belgium                          127839.350        89553.600
    Bosnia and Herzegovina            23360.120        17319.433
    Bulgaria                          60863.928        41330.546
    Croatia                           15521.400        28779.200
    Cyprus                            13504.990         3641.232
    Czechia                          155403.895        39911.488
    Denmark                           53367.075        86509.218
    Estonia                           16424.750         7520.090
    Faroe Islands                       804.480          540.105
    Finland                           84308.000        80993.000
    France                           755148.825       489891.341
    Germany                          931995.500      1145617.500
    Greece                            93268.034        97053.141
    Hungary                           68793.000        26105.000
    Iceland                            1077.974        25277.052
    Ireland                           59505.916        38979.374
    Italy                            559477.705       498258.997
    Kosovo                            10846.000         1276.930
    Latvia                            10060.871        16730.759
    Lithuania                         23538.500        10576.251
    Luxembourg                        12883.701         3854.863
    Malta                              5011.000         1450.996
    Moldova                           26568.000         1268.338
    Montenegro                         2025.000         6946.651
    Netherlands                      224106.304       150414.665
    North Macedonia                   10536.000         7619.592
    Norway                             8934.672       326089.950
    Poland                           305631.765       119027.954
    Portugal                          61684.156       131578.406
    Romania                           90737.497       101441.157
    Serbia                            45431.741        25119.661
    Slovakia                          47097.000        21610.080
    Slovenia                          20420.580        14767.275
    Spain                            481095.646       519615.745
    Sweden                           106216.000       287853.648
    Switzerland                       40279.500       162167.340
    Ukraine                          414940.000        96696.736
    United Kingdom                   524478.016       402260.977
    


```python
# Calculation of correlation between columns
correlation = pivot_table['Total_Renewable'].corr(pivot_table['Total_Non_Renewable'])

correlation_rounded = round(correlation, 2)

print("Correlation between Total Renewable and Total Non-Renewable energy:", correlation_rounded)
```

    Correlation between Total Renewable and Total Non-Renewable energy: 0.88
    


```python
# A correlation of 0.88 between renewable and non-renewable energy produced indicates that in most countries with increased generation
# one type of energy usually also increases the production of another type. This may indicate that countries are generally developing their energy
# infrastructure from both renewable and non-renewable energy sources.
# Power generation from both sources can be interconnected through the development of the energy sector and this can be positive
# sign for sustainable development and diversification of energy sources in Europe.
```


```python
# Grouping by country and calculating the average GDP
average_gdp = gdp_data.groupby('Country')['GDP'].mean().reset_index()

print(average_gdp)
```

                       Country          GDP
    0                  Albania    15.763111
    1                  Andorra     3.146667
    2                  Austria   445.124889
    3                  Belarus    61.783111
    4                  Belgium   539.809889
    5   Bosnia and Herzegovina    20.901000
    6                 Bulgaria    71.910222
    7                  Croatia    62.334333
    8                   Cyprus    25.681000
    9                  Czechia   250.895333
    10                 Denmark   359.185333
    11                 Estonia    31.561778
    12           Faroe Islands     3.226667
    13                 Finland   270.207889
    14                  France  2718.001556
    15                 Germany  3895.605222
    16                  Greece   207.676889
    17                 Hungary   160.218333
    18                 Iceland    24.419667
    19                 Ireland   419.833444
    20                   Italy  2007.486778
    21                  Kosovo     8.105111
    22                  Latvia    35.102222
    23               Lithuania    57.218556
    24              Luxembourg    73.212444
    25                   Malta    15.490778
    26                 Moldova    11.558111
    27              Montenegro     5.361889
    28             Netherlands   916.595333
    29         North Macedonia    12.562111
    30                  Norway   446.723556
    31                  Poland   607.522333
    32                Portugal   236.186000
    33                 Romania   250.659000
    34                  Serbia    53.524222
    35                Slovakia   106.685222
    36                Slovenia    54.339222
    37                   Spain  1364.735000
    38                  Sweden   558.523333
    39             Switzerland   755.963444
    40                 Ukraine   141.283556
    41          United Kingdom  2920.039778
    


```python
# Grouping by country and calculating the average value of energy produced from renewable sources
average_renewable_energy = renewable_energy_data.groupby('Country')['Electricity_Installed_Capacity__MW_'].mean().reset_index()

print(average_renewable_energy)
```

                       Country  Electricity_Installed_Capacity__MW_
    0                  Albania                           584.552083
    1                  Andorra                            14.087943
    2                  Austria                          1665.211937
    3                  Belarus                          1535.178387
    4                  Belgium                          1341.931790
    5   Bosnia and Herzegovina                           473.018058
    6                 Bulgaria                          1098.865312
    7                  Croatia                           509.202299
    8                   Cyprus                           336.200431
    9                  Czechia                          1375.460444
    10                 Denmark                          1075.971485
    11                 Estonia                           272.100455
    12           Faroe Islands                            32.794756
    13                 Finland                          1836.677778
    14                  France                          7196.763965
    15                 Germany                         10546.258883
    16                  Greece                          2114.679722
    17                 Hungary                          1078.386364
    18                 Iceland                           560.745234
    19                 Ireland                           841.754615
    20                   Italy                          6529.238901
    21                  Kosovo                           336.748056
    22                  Latvia                           347.943247
    23               Lithuania                           328.026452
    24              Luxembourg                           169.076404
    25                   Malta                           129.239920
    26                 Moldova                           448.973194
    27              Montenegro                           309.367276
    28             Netherlands                          3201.033923
    29         North Macedonia                           252.161000
    30                  Norway                          2701.811468
    31                  Poland                          2990.561401
    32                Portugal                          1207.891012
    33                 Romania                          1813.006170
    34                  Serbia                           734.910438
    35                Slovakia                           694.010909
    36                Slovenia                           325.813472
    37                   Spain                          6293.782333
    38                  Sweden                          2542.384826
    39             Switzerland                          1874.507778
    40                 Ukraine                          6316.502914
    41          United Kingdom                          5516.303530
    


```python
# Combining tables by country
merged_data = pd.merge(average_gdp, average_renewable_energy, on='Country')

# Correlation between the indicators of the average GDP in the country and the average value of energy produced from renewable sources
correlation = merged_data['GDP'].corr(merged_data['Electricity_Installed_Capacity__MW_'])

correlation_rounded = round(correlation, 2)

print("Correlation between average GDP and Renewable Energy Production:", correlation_rounded)
```

    Correlation between average GDP and Renewable Energy Production: 0.89
    


```python
import matplotlib.pyplot as plt

# Data for the graph
x = average_gdp['GDP']  # Середній ВВП
y = average_renewable_energy['Electricity_Installed_Capacity__MW_']  # Average energy production from renewable sources

# Create a scatter plot
plt.figure(figsize=(8, 6))
plt.scatter(x, y, color='blue', alpha=0.7)
plt.title('Scatter Plot of GDP vs Renewable Energy Production')
plt.xlabel('Average GDP')
plt.ylabel('Average Renewable Energy Production')
plt.grid(True)
plt.show()

```


    
![png](output_9_0.png)
    



```python
# The graph shows the distribution of average GDP on the X axis and average energy production from renewable sources on the Y axis.
# Correlation is determined by placing points on the graph.
# The points are close to each other and are directed in the same direction, this indicates a positive correlation.
```


```python
# The correlation at 0.89 between GDP and renewable energy production suggests that there is a fairly strong positive relationship
# between these two measures for the countries in question. This means that with GDP growth in these countries, the probability of production growth
# renewable energy also increases.

# This result may indicate that countries with higher levels of economic development are more likely to invest in renewable energy,
# which contributes to the preservation of the environment and creates new opportunities for economic growth.
```


```python
# Creating pivot table to calculate the total amount of energy produced from renewable and non-renewable sources depending on the year, 
# cumulatively for all European countries
pivot_table_year = renewable_energy_data.pivot_table(index='Year', columns='RE_or_Non_RE', values='Electricity_Installed_Capacity__MW_', aggfunc='sum')

# Rename columns for convenience
pivot_table_year.rename(columns={'Total Renewable': 'Total_Renewable', 'Total Non-Renewable': 'Total_Non_Renewable'}, inplace=True)

print(pivot_table_year)
```

    RE_or_Non_RE  Total_Non_Renewable  Total_Renewable
    Year                                              
    2015                   661476.276       465121.006
    2016                   649312.666       488668.776
    2017                   640383.285       512996.314
    2018                   644333.198       537481.639
    2019                   625254.520       574837.777
    2020                   613407.518       609123.480
    2021                   604762.304       651431.987
    2022                   599124.127       715535.319
    2023                   595312.537       786780.985
    


```python
import seaborn as sns

# Convert a table to a long form
melted_df = pivot_table_year.reset_index().melt(id_vars='Year', var_name='Energy_Type', value_name='Electricity_Installed_Capacity__MW_')

# Plotting with Seaborn
plt.figure(figsize=(10, 6))
sns.lineplot(data=melted_df, x='Year', y='Electricity_Installed_Capacity__MW_', hue='Energy_Type', marker='o')
plt.title('Energy Production Over the Years')
plt.xlabel('Year')
plt.ylabel('Electricity Installed Capacity (MW)')
plt.grid(True)
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

```

    C:\Users\Tetiana_Lopatynska\AppData\Local\anaconda3\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    C:\Users\Tetiana_Lopatynska\AppData\Local\anaconda3\Lib\site-packages\seaborn\_oldcore.py:1119: FutureWarning: use_inf_as_na option is deprecated and will be removed in a future version. Convert inf values to NaN before operating instead.
      with pd.option_context('mode.use_inf_as_na', True):
    


    
![png](output_13_1.png)
    



```python
# The general conclusion on the dynamics of energy production in Europe based on the data obtained shows,
# that renewable energy production has been growing for eight years, while non-renewable energy production has been declining.
# In 2015, energy generation from renewable sources was 465121.006 MW, and from non-renewable sources - 661476.276 MW.
# Over the following years, renewable energy production grew, reaching its highest rate in 2023 (786780.985 MW),
# while energy production from non-renewable sources gradually decreased, reaching the lowest rate in 2023 (595312.537 MW).

# Thus, based on these data, we can conclude that European countries pay more attention to the production of energy from renewable sources
# and gradually move away from the use of non-renewable energy sources.
```
